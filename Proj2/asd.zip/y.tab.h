#define IF 257
#define ELSE 258
#define ASSIGN 259
#define DIF 260
#define GE 261
#define LE 262
#define INC 263
#define DEC 264
#define INT 265
#define STR 266
#define ID 267
#define NUM 268
#define VOID 269
#define INTEGER 270
#define STRING 271
#define NUMBER 272
#define FOR 273
#define PUBLIC 274
#define CONST 275
#define THEN 276
#define WHILE 277
#define DO 278
#define IN 279
#define STEP 280
#define UPTO 281
#define DOWNTO 282
#define BREAK 283
#define CONTINUE 284
#define FILES 285
#define NIL 286
#define DECLS 287
#define DECL 288
#define TYPE 289
#define IDp 290
#define VECT 291
#define INDIRECAO 292
#define SIM 293
#define MUL 294
#define DIV 295
#define RES 296
#define ADD 297
#define MIN 298
#define LESSER 299
#define GREATER 300
#define EQ 301
#define AND 302
#define OR 303
#define FUNC 304
#define FACT 305
#define INIT 306
#define PARAMS 307
#define PARAM 308
#define BODY 309
#define INSTRUCAO 310
#define INSTR 311
#define ARGS 312
#define ENDDECLS 313
#define ENDINIT 314
#define START 315
#define ALLOCATE 316
#define INSTRUCAOS 317
#define NULLARGS 318
#define NOSTEP 319
#define INFO 320
#define LOCALIZACAO 321
#define ERROR 322
#define VAR 323
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union {
	int i;			/* integer value */
	char* s;
	double d;
	Node *n;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
extern YYSTYPE yylval;
