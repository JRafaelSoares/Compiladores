/* original parser id follows */
/* yysccsid[] = "@(#)yaccpar	1.9 (Berkeley) 02/21/93" */
/* (use YYMAJOR/YYMINOR for ifdefs dependent on parser version) */

#define YYBYACC 1
#define YYMAJOR 1
#define YYMINOR 9
#define YYPATCH 20140715

#define YYEMPTY        (-1)
#define yyclearin      (yychar = YYEMPTY)
#define yyerrok        (yyerrflag = 0)
#define YYRECOVERING() (yyerrflag != 0)
#define YYENOMEM       (-2)
#define YYEOF          0
#define YYPREFIX "yy"

#define YYPURE 0

#line 2 "diy.y"
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "node.h"
#include "tabid.h"
extern int yylex();

int checkRightConst(Node* expr);
int checkLogics(Node* expr1, Node* expr2, char* errorMessage);
int checkZero(Node* expr);
int checkAddress(int type);
int checkMakePointer(Node* expr);
int checkIncrements(Node* expr, char* errorMessage);
int checkSimetric(Node* expr, char* errorMessage);
int checkCalculus(Node* expr1, Node* expr2, char* errorMessage);
int checkFactorial(Node* expr, char* errorMessage);
int checkComparisons(Node* expr1, Node* expr2, char* errorMessage);
int checkPointer(Node* expr);
int checkConst(Node* expr);
int checkVector(int type);
int checkAssign(Node* leftValue, Node* expr);
void setFunctionParameters(Node* params);
struct Args* getParameters(Node* params);
void existsID(Node* type, char* name);
void checkID(Node *type, int idType);
void checkStringDecl(Node *type);
void checkIntDecl(Node* type, int value);
void checkNumDecl(Node* type, int value);
void declareFunction(Node* typeFunc, char* name, Node* params);
int checkString(Node* expr);
int checkReal(Node* expr);
int checkInt(Node* expr);
int checkIntReal(Node* first, Node* second);
void checkDecl(Node* type, Node* init);
void checkArgs(Node* type, Node* init);
int yyerror(char *s);

struct Args { int type; char* name; struct Args *next; };

void printStruct(struct Args* asd);

#define tINTEGER 1
#define tSTRING 2
#define tNUMBER 3
#define tVOID 4
#define tCONSTL 8
#define tPOINTER 16
#define tFUNCT 32
#define tCONSTR 64
#define tZero 128

/*
integer - 1
string - 2
number - 3
void - 4
constl - 8
pointer - 16
funct - 32
constr - 64

*/
int level = 0;

#line 69 "diy.y"
#ifdef YYSTYPE
#undef  YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
#endif
#ifndef YYSTYPE_IS_DECLARED
#define YYSTYPE_IS_DECLARED 1
typedef union {
	int i;			/* integer value */
	char* s;
	double d;
	Node *n;
} YYSTYPE;
#endif /* !YYSTYPE_IS_DECLARED */
#line 101 "y.tab.c"

/* compatibility with bison */
#ifdef YYPARSE_PARAM
/* compatibility with FreeBSD */
# ifdef YYPARSE_PARAM_TYPE
#  define YYPARSE_DECL() yyparse(YYPARSE_PARAM_TYPE YYPARSE_PARAM)
# else
#  define YYPARSE_DECL() yyparse(void *YYPARSE_PARAM)
# endif
#else
# define YYPARSE_DECL() yyparse(void)
#endif

/* Parameters sent to lex. */
#ifdef YYLEX_PARAM
# define YYLEX_DECL() yylex(void *YYLEX_PARAM)
# define YYLEX yylex(YYLEX_PARAM)
#else
# define YYLEX_DECL() yylex(void)
# define YYLEX yylex()
#endif

/* Parameters sent to yyerror. */
#ifndef YYERROR_DECL
#define YYERROR_DECL() yyerror(const char *s)
#endif
#ifndef YYERROR_CALL
#define YYERROR_CALL(msg) yyerror(msg)
#endif

extern int YYPARSE_DECL();

#define IF 257
#define ELSE 258
#define ASSIGN 259
#define DIF 260
#define GE 261
#define LE 262
#define INC 263
#define DEC 264
#define INT 265
#define STR 266
#define ID 267
#define NUM 268
#define VOID 269
#define INTEGER 270
#define STRING 271
#define NUMBER 272
#define FOR 273
#define PUBLIC 274
#define CONST 275
#define THEN 276
#define WHILE 277
#define DO 278
#define IN 279
#define STEP 280
#define UPTO 281
#define DOWNTO 282
#define BREAK 283
#define CONTINUE 284
#define FILES 285
#define NIL 286
#define DECLS 287
#define DECL 288
#define TYPE 289
#define IDp 290
#define VECT 291
#define INDIRECAO 292
#define SIM 293
#define MUL 294
#define DIV 295
#define RES 296
#define ADD 297
#define MIN 298
#define LESSER 299
#define GREATER 300
#define EQ 301
#define AND 302
#define OR 303
#define FUNC 304
#define FACT 305
#define INIT 306
#define PARAMS 307
#define PARAM 308
#define BODY 309
#define INSTRUCAO 310
#define INSTR 311
#define ARGS 312
#define ENDDECLS 313
#define ENDINIT 314
#define START 315
#define ALLOCATE 316
#define INSTRUCAOS 317
#define NULLARGS 318
#define NOSTEP 319
#define INFO 320
#define LOCALIZACAO 321
#define ERROR 322
#define VAR 323
#define YYERRCODE 256
typedef short YYINT;
static const YYINT yylhs[] = {                           -1,
    0,    1,    1,    2,    2,    2,    2,    2,    2,   16,
   16,   16,   16,   16,   16,   16,   16,   16,   16,   16,
   16,   16,   16,   16,   16,   17,    4,    4,   18,    4,
    4,   19,    4,    4,   20,    4,    4,    8,    8,   10,
   10,   10,   10,    9,    9,    3,    3,    3,    3,    3,
    3,    6,    6,    7,    7,    7,    7,    7,    7,    7,
    7,    7,    7,    7,    7,    7,    7,    7,    7,    7,
    7,    7,    7,    7,    7,    7,    7,    7,    7,    7,
    5,    5,    5,    5,    5,   11,   11,   12,   12,   12,
   12,   12,   12,   12,   12,   12,   22,   12,   12,   12,
   21,   13,   13,   15,   15,   15,   14,   14,
};
static const YYINT yylen[] = {                            2,
    1,    2,    0,    3,    3,    2,    2,    2,    2,    5,
    6,    6,    5,    5,    6,    5,    3,    4,    5,    5,
    4,    4,    5,    4,    2,    0,    9,    5,    0,    9,
    5,    0,    8,    4,    0,    8,    4,    4,    2,    2,
    1,    1,    0,    4,    3,    1,    1,    1,    2,    2,
    2,    1,    4,    3,    4,    3,    2,    2,    2,    2,
    2,    2,    2,    2,    3,    3,    3,    3,    3,    3,
    3,    3,    3,    3,    3,    2,    3,    3,    3,    1,
    1,    2,    1,    1,    1,    2,    1,    5,    7,    6,
   10,   10,    2,    3,    3,    4,    0,    4,    2,    2,
    0,    1,    0,    2,    2,    0,    3,    1,
};
static const YYINT yydefred[] = {                         3,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    2,
    0,    0,    0,    8,    9,    0,   49,   50,   51,    0,
    0,    0,    0,    7,    6,    0,    5,    4,    0,    0,
    0,    0,    0,    0,    0,    0,   18,   21,   24,   22,
    0,    0,    0,   35,   39,    0,    0,    0,   10,   13,
   16,   14,    0,   19,   23,   20,   32,    0,    0,   29,
    0,   11,   15,   12,    0,   26,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   81,   83,    0,   84,
    0,    0,  101,    0,    0,   97,    0,   80,    0,    0,
    0,    0,    0,   87,    0,   38,    0,    0,   99,  100,
    0,    0,    0,   57,    0,    0,    0,   59,   61,   62,
    0,    0,    0,    0,   82,    0,  102,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   63,   64,   93,    0,
    0,   36,   86,    0,   33,    0,    0,   54,    0,   56,
    0,    0,    0,    0,   94,   95,    0,   45,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   30,   27,    0,   53,   55,    0,
    0,    0,   98,   96,   44,    0,    0,    0,    0,    0,
    0,    0,    0,   90,   89,    0,  101,  101,  104,  105,
    0,    0,    0,    0,   91,   92,
};
static const YYINT yydgoto[] = {                          1,
    2,   10,   87,   12,   88,  101,   90,   34,   91,   92,
   93,   94,  118,  152,  197,   13,   98,   95,   65,   59,
  116,  120,
};
static const YYINT yysindex[] = {                         0,
    0,  -70,  -53, -257,  -11,   -9,   -1,  -63, -210,    0,
 -218,   -7,   -5,    0,    0,   16,    0,    0,    0,   -2,
    5, -202,  -37,    0,    0,   22,    0,    0, -188,   95,
   78,  -48, -189,  -30,  125, -250,    0,    0,    0,    0,
 -181,  -36,  -25,    0,    0,  -31, -210, -244,    0,    0,
    0,    0, -177,    0,    0,    0,    0,  -28,  -33,    0,
 -173,    0,    0,    0,  -33,    0,  -46,  752, -171,  752,
  752,  752,  752,  752,  752,  752,    0,    0,  -32,    0,
 -171, -169,    0, -160, -160,    0, -156,    0,  -34,  820,
  -33,   -8,   13,    0,  -33,    0,    3,  -33,    0,    0,
 -145, 1056,   32,    0,  944,  -20, -226,    0,    0,    0,
  849,  752,  746, -150,    0,   13,    0,   74,   75,  -33,
   85,  752,  752,  752,  752,  752,  752,  752,  752,  752,
  752,  752,  752,  752,  752,  752,    0,    0,    0, -130,
   13,    0,    0,   20,    0,   26, -122,    0,  937,    0,
 1056,  -15,  752, -120,    0,    0,   30,    0, 1056,  877,
 1082,  944,  898,  898,   -3,   -3,   -3,   -3,  -20,  -20,
 -226, -226, -226,  100,    0,    0,   13,    0,    0,  752,
  398,  752,    0,    0,    0,  -98, 1056,  752,  752,  991,
   13,  591,  591,    0,    0, -263,    0,    0,    0,    0,
 -117, -116,   13,   13,    0,    0,
};
static const YYINT yyrindex[] = {                         0,
    0,  168,    0,    0,  -96,  -93,  -92,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,   -5,    0,    0,    0,    0,    0,  110,    0,
    0,  122,    0,    0,    0,    0,    0,    0,    0,    0,
    0,  124,    0,    0,    0,  126,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    5,   59,    0,
    0,    0,    0,    0,   59,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,   39,    0,
    0,    0,    0,  128,  128,    0,    0,    0, 1026,    0,
   63,    0,   66,    0,   59,    0,    0,   59,    0,    0,
  105,  -84,   65,    0,   29,  412,  135,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,   59,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   68,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    4,    0,    0,    0,    0,    0,    0,    0,  690,    0,
  681,   97,  476,  547,  485,  520,  557,  645,  438,  448,
  295,  361,  387,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,  -10,    6,    0,    0,    0,
    0,  -75,  -75,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,
};
static const YYINT yygindex[] = {                         0,
    0,    0,  493,  202,    0, 1144, 1237,  180,    0,  -29,
  123,  -73,  130,    0,   23,  205,    0,    0,    0,    0,
  -77,    0,
};
#define YYTABLESIZE 1426
static const YYINT yytable[] = {                         73,
  123,  199,   31,  103,   69,   14,   76,  113,   72,   16,
   46,   71,   99,   47,   54,   58,  136,   55,   47,  143,
   62,  134,   88,   63,  147,  179,  135,   88,  180,   88,
   17,   88,   18,  136,   88,   97,  137,  138,  134,  132,
   19,  133,  154,  135,  108,   73,  107,  108,   23,  107,
   69,   24,   76,   25,   72,   26,   27,   71,  112,    5,
    6,    7,   32,   28,   29,  144,   76,  143,  146,   76,
   35,   15,   76,   52,   44,   52,   52,   45,  100,   52,
   52,   52,   52,   52,   56,   52,   57,   76,   64,   86,
  157,   60,   70,   96,   66,  103,  115,   52,   52,   52,
   52,   52,   52,  186,  117,   52,   52,   52,   52,   52,
  121,   52,   88,  122,   88,   88,  142,  195,   42,  201,
  202,   76,  112,   52,   52,   52,   52,  145,  153,  205,
  206,   52,  155,  156,   77,   86,  174,   77,   70,   36,
   77,   85,   85,  158,  175,   85,   85,   85,   85,   85,
  176,   85,   76,  177,  183,   77,  182,   52,  185,  191,
  203,  204,   52,   85,   85,   85,   85,    1,   17,   48,
   46,   58,   58,   47,   48,   58,   58,   58,   58,   58,
   37,   58,   34,   43,   31,    3,  103,   41,   52,   77,
   42,  101,   40,   58,   58,   58,   58,   85,    4,    5,
    6,    7,  106,    8,    9,    4,    5,    6,    7,   20,
   43,    9,   21,  141,  119,  198,    0,    0,    0,    0,
   77,   30,   67,   68,  122,    0,    0,   58,   85,   74,
   75,   77,   78,   79,   80,    0,    5,    6,    7,   81,
    0,   82,  137,  138,   83,   88,   88,    0,    0,   84,
   85,    0,   88,   88,   88,   88,   88,   88,   58,  137,
  138,    0,   88,    0,   88,    0,   88,   88,   67,   68,
    0,    0,   88,   88,    0,   74,   75,   77,   78,   79,
   80,    0,    0,    0,    0,   81,    0,   82,    0,    0,
   83,    5,    6,    7,    0,   84,   85,   52,   52,   52,
   52,   52,   52,    0,   76,    0,   76,    0,   76,   76,
   76,    0,    0,    0,   52,    0,   52,    0,   52,   52,
   52,    0,    0,    0,   52,   52,   52,   52,   52,    0,
    0,   65,   65,    0,    0,   65,   65,   65,   65,   65,
   52,   65,   52,   52,   52,   52,   52,    5,    6,    7,
    0,    0,    0,   65,   65,   65,   65,    0,    0,   37,
   38,   39,   40,    0,   85,   85,   85,   85,   85,   41,
    0,    0,   77,    0,   77,    0,   77,   77,   77,    0,
   85,    0,   85,    0,   85,   85,   85,   65,    0,   49,
   50,   51,   52,    0,   58,   58,   58,   66,   66,   53,
    0,   66,   66,   66,   66,   66,    0,   66,    0,    0,
   58,    0,   58,    0,   58,   58,   58,    0,   65,   66,
   66,   66,   66,   67,   67,    0,    0,   67,   67,   67,
   67,   67,    0,   67,  136,  125,    0,    0,    0,  134,
  132,    0,  133,    0,  135,   67,   67,   67,   67,   60,
    0,    0,   60,   66,   60,   60,   60,  128,  126,  129,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
   60,   60,   60,   60,    0,   68,    0,    0,   68,   67,
   68,   68,   68,    0,   66,   69,    0,    0,   69,    0,
   69,   69,   69,    0,   11,    0,   68,   68,   68,   68,
   11,   22,    0,    0,   60,    0,   69,   69,   69,   69,
   67,    0,    0,   74,    0,    0,   74,    0,   33,   74,
    0,  124,   70,   33,    0,   70,    0,    0,   70,    0,
   68,    0,    0,    0,   74,   60,   74,    0,    0,   61,
   69,    0,    0,   70,   70,   70,   70,    0,    0,    0,
    0,    0,    0,    0,   65,   65,   65,   71,    0,    0,
   71,   68,    0,   71,    0,    0,    0,    0,   74,    0,
   65,   69,   65,    0,   65,   65,   65,   70,   71,   71,
   71,   71,    0,  140,   75,    0,    0,   75,    0,    0,
   75,    0,    0,    0,   72,    0,    0,   72,    0,   74,
   72,    0,    0,    0,    0,   75,    0,   75,   70,    0,
    0,    0,   71,    0,    0,   72,   72,   72,   72,    0,
   66,   66,   66,    0,    0,    0,    0,  136,  125,    0,
    0,    0,  134,  132,    0,  133,   66,  135,   66,   75,
   66,   66,   66,   71,    0,    0,   67,   67,   67,   72,
  128,  126,  129,    0,    0,    0,    0,  127,  130,  131,
  137,  138,   67,    0,   67,    0,   67,   67,   67,    0,
   75,   60,   60,   60,    0,    0,    0,    0,  188,  189,
   72,    0,   73,    0,    0,   73,    0,   60,   73,   60,
    0,   60,   60,   60,    0,    0,    0,   68,   68,   68,
    0,    0,    0,   73,   73,   73,   73,   69,   69,   69,
    0,    0,    0,   68,  124,   68,    0,   68,   68,   68,
    0,   78,    0,   69,   78,   69,    0,   69,   69,   69,
   79,    0,    0,   79,    0,   74,    0,   73,    0,   78,
    0,    0,    0,    0,   70,   70,   70,    0,   79,    0,
    0,   74,    0,   74,    0,   74,   74,   74,    0,    0,
   70,    0,   70,    0,   70,   70,   70,    0,   73,    0,
    0,    0,    0,   78,    0,    0,    0,    0,   73,   71,
   71,   71,   79,   69,   73,   76,  150,   72,    0,   69,
   71,   76,    0,   72,    0,   71,   71,   71,    0,   71,
   71,   71,    0,    0,   78,    0,   75,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   72,   72,   72,    0,
    0,    0,   75,    0,   75,    0,   75,   75,   75,    0,
    0,    0,   72,    0,   72,    0,   72,   72,   72,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
  127,  130,  131,  137,  138,    0,  136,  125,    0,    0,
    0,  134,  132,    0,  133,    0,  135,    0,    0,    0,
  196,   70,    0,    0,    0,    0,    0,   70,  139,  128,
  126,  129,    0,    0,    0,  136,  125,    0,    0,  148,
  134,  132,    0,  133,    0,  135,    0,    0,    0,    0,
    0,    0,    0,    0,   73,   73,   73,    0,  128,  126,
  129,    0,    0,  136,  125,    0,    0,    0,  134,  132,
   73,  133,   73,  135,   73,   73,   73,    0,    0,    0,
    0,    0,    0,    0,  136,  184,  128,  126,  129,  134,
  132,    0,  133,  124,  135,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,   78,  128,   78,  129,
   78,   78,   78,    0,    0,   79,    0,   79,    0,   79,
   79,   79,  124,  136,  125,    0,    0,    0,  134,  132,
  136,  133,    0,  135,    0,  134,  132,    0,  133,    0,
  135,    0,    0,    0,    0,    0,  128,  126,  129,    0,
  124,    0,    0,  128,  126,  129,    0,    0,   74,   75,
   77,   78,   79,   80,   74,   75,   77,   78,   79,   80,
   82,    0,    0,    0,    0,    0,   82,  136,  125,  178,
    0,    0,  134,  132,    0,  133,    0,  135,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,  194,
  128,  126,  129,    0,    0,    0,    0,    0,    0,    0,
  124,    0,   85,   85,    0,    0,    0,   85,   85,    0,
   85,    0,   85,    0,    0,    0,    0,    0,    0,  127,
  130,  131,  137,  138,   85,   85,   85,   85,    0,    0,
    0,    0,  136,  125,    0,    0,    0,  134,  132,    0,
  133,    0,  135,    0,    0,    0,    0,    0,  127,  130,
  131,  137,  138,    0,  124,  128,  126,  129,  136,  125,
    0,    0,    0,  134,  132,    0,  133,    0,  135,    0,
    0,    0,    0,    0,    0,    0,  127,  130,  131,  137,
  138,  128,  126,  129,    0,    0,    0,    0,    0,   85,
    0,    0,    0,    0,    0,    0,    0,    0,  130,  131,
  137,  138,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,  124,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  127,  130,  131,  137,
  138,    0,   89,  127,  130,  131,  137,  138,   89,    0,
    0,    0,  104,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  114,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   89,    0,   89,    0,   89,    0,
    0,   89,    0,    0,    0,    0,    0,    0,    0,    0,
  127,  130,  131,  137,  138,    0,    0,    0,    0,   89,
    0,    0,    0,   89,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   89,   85,   85,   85,   85,   85,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,  102,    0,  105,  106,  107,  108,
  109,  110,  111,    0,    0,  127,  130,  131,  137,  138,
   89,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,   89,    0,    0,    0,    0,  200,
    0,  127,  130,  131,  137,  138,   89,   89,  149,  151,
    0,    0,    0,    0,    0,    0,    0,    0,  159,  160,
  161,  162,  163,  164,  165,  166,  167,  168,  169,  170,
  171,  172,  173,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,  181,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,  187,    0,  190,    0,
    0,    0,    0,    0,  192,  193,
};
static const YYINT yycheck[] = {                         33,
   35,  265,   40,  267,   38,   59,   40,   40,   42,  267,
   41,   45,   59,   44,  265,   41,   37,  268,   44,   93,
  265,   42,   33,  268,  102,   41,   47,   38,   44,   40,
   42,   42,   42,   37,   45,   65,  263,  264,   42,   43,
   42,   45,  116,   47,   41,   33,   41,   44,  267,   44,
   38,   59,   40,   59,   42,   40,   59,   45,   91,  270,
  271,  272,   41,   59,  267,   95,   38,  141,   98,   41,
  259,  125,   44,   35,  123,   37,   38,  267,  125,   41,
   42,   43,   44,   45,  266,   47,  123,   59,  266,  123,
  120,  123,  126,  267,  123,  267,  266,   59,   60,   61,
   62,   37,   38,  177,  265,   41,   42,   43,   44,   45,
  267,   47,  123,  259,  125,  126,  125,  191,   41,  197,
  198,   93,   91,   59,   60,   61,   62,  125,  279,  203,
  204,   93,   59,   59,   38,  123,  267,   41,  126,   45,
   44,   37,   38,   59,  125,   41,   42,   43,   44,   45,
  125,   47,  124,  276,  125,   59,  277,   93,   59,  258,
  278,  278,  124,   59,   60,   61,   62,    0,   59,   45,
  267,   37,   38,  267,  267,   41,   42,   43,   44,   45,
   59,   47,   59,  125,   59,  256,   59,  125,  124,   93,
  125,  276,  125,   59,   60,   61,   62,   93,  269,  270,
  271,  272,  278,  274,  275,  269,  270,  271,  272,    8,
   31,  275,    8,   91,   85,  193,   -1,   -1,   -1,   -1,
  124,  259,  256,  257,  259,   -1,   -1,   93,  124,  263,
  264,  265,  266,  267,  268,   -1,  270,  271,  272,  273,
   -1,  275,  263,  264,  278,  256,  257,   -1,   -1,  283,
  284,   -1,  263,  264,  265,  266,  267,  268,  124,  263,
  264,   -1,  273,   -1,  275,   -1,  277,  278,  256,  257,
   -1,   -1,  283,  284,   -1,  263,  264,  265,  266,  267,
  268,   -1,   -1,   -1,   -1,  273,   -1,  275,   -1,   -1,
  278,  270,  271,  272,   -1,  283,  284,  259,  260,  261,
  262,  263,  264,   -1,  276,   -1,  278,   -1,  280,  281,
  282,   -1,   -1,   -1,  276,   -1,  278,   -1,  280,  281,
  282,   -1,   -1,   -1,  260,  261,  262,  263,  264,   -1,
   -1,   37,   38,   -1,   -1,   41,   42,   43,   44,   45,
  276,   47,  278,  279,  280,  281,  282,  270,  271,  272,
   -1,   -1,   -1,   59,   60,   61,   62,   -1,   -1,  265,
  266,  267,  268,   -1,  260,  261,  262,  263,  264,  275,
   -1,   -1,  276,   -1,  278,   -1,  280,  281,  282,   -1,
  276,   -1,  278,   -1,  280,  281,  282,   93,   -1,  265,
  266,  267,  268,   -1,  260,  261,  262,   37,   38,  275,
   -1,   41,   42,   43,   44,   45,   -1,   47,   -1,   -1,
  276,   -1,  278,   -1,  280,  281,  282,   -1,  124,   59,
   60,   61,   62,   37,   38,   -1,   -1,   41,   42,   43,
   44,   45,   -1,   47,   37,   38,   -1,   -1,   -1,   42,
   43,   -1,   45,   -1,   47,   59,   60,   61,   62,   38,
   -1,   -1,   41,   93,   43,   44,   45,   60,   61,   62,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   59,   60,   61,   62,   -1,   38,   -1,   -1,   41,   93,
   43,   44,   45,   -1,  124,   38,   -1,   -1,   41,   -1,
   43,   44,   45,   -1,    2,   -1,   59,   60,   61,   62,
    8,    9,   -1,   -1,   93,   -1,   59,   60,   61,   62,
  124,   -1,   -1,   38,   -1,   -1,   41,   -1,   26,   44,
   -1,  124,   38,   31,   -1,   41,   -1,   -1,   44,   -1,
   93,   -1,   -1,   -1,   59,  124,   61,   -1,   -1,   47,
   93,   -1,   -1,   59,   60,   61,   62,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  260,  261,  262,   38,   -1,   -1,
   41,  124,   -1,   44,   -1,   -1,   -1,   -1,   93,   -1,
  276,  124,  278,   -1,  280,  281,  282,   93,   59,   60,
   61,   62,   -1,   91,   38,   -1,   -1,   41,   -1,   -1,
   44,   -1,   -1,   -1,   38,   -1,   -1,   41,   -1,  124,
   44,   -1,   -1,   -1,   -1,   59,   -1,   61,  124,   -1,
   -1,   -1,   93,   -1,   -1,   59,   60,   61,   62,   -1,
  260,  261,  262,   -1,   -1,   -1,   -1,   37,   38,   -1,
   -1,   -1,   42,   43,   -1,   45,  276,   47,  278,   93,
  280,  281,  282,  124,   -1,   -1,  260,  261,  262,   93,
   60,   61,   62,   -1,   -1,   -1,   -1,  260,  261,  262,
  263,  264,  276,   -1,  278,   -1,  280,  281,  282,   -1,
  124,  260,  261,  262,   -1,   -1,   -1,   -1,  281,  282,
  124,   -1,   38,   -1,   -1,   41,   -1,  276,   44,  278,
   -1,  280,  281,  282,   -1,   -1,   -1,  260,  261,  262,
   -1,   -1,   -1,   59,   60,   61,   62,  260,  261,  262,
   -1,   -1,   -1,  276,  124,  278,   -1,  280,  281,  282,
   -1,   41,   -1,  276,   44,  278,   -1,  280,  281,  282,
   41,   -1,   -1,   44,   -1,  260,   -1,   93,   -1,   59,
   -1,   -1,   -1,   -1,  260,  261,  262,   -1,   59,   -1,
   -1,  276,   -1,  278,   -1,  280,  281,  282,   -1,   -1,
  276,   -1,  278,   -1,  280,  281,  282,   -1,  124,   -1,
   -1,   -1,   -1,   93,   -1,   -1,   -1,   -1,   33,  260,
  261,  262,   93,   38,   33,   40,   41,   42,   -1,   38,
   45,   40,   -1,   42,   -1,  276,   45,  278,   -1,  280,
  281,  282,   -1,   -1,  124,   -1,  260,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  260,  261,  262,   -1,
   -1,   -1,  276,   -1,  278,   -1,  280,  281,  282,   -1,
   -1,   -1,  276,   -1,  278,   -1,  280,  281,  282,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
  260,  261,  262,  263,  264,   -1,   37,   38,   -1,   -1,
   -1,   42,   43,   -1,   45,   -1,   47,   -1,   -1,   -1,
  280,  126,   -1,   -1,   -1,   -1,   -1,  126,   59,   60,
   61,   62,   -1,   -1,   -1,   37,   38,   -1,   -1,   41,
   42,   43,   -1,   45,   -1,   47,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  260,  261,  262,   -1,   60,   61,
   62,   -1,   -1,   37,   38,   -1,   -1,   -1,   42,   43,
  276,   45,  278,   47,  280,  281,  282,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   37,   59,   60,   61,   62,   42,
   43,   -1,   45,  124,   47,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  276,   60,  278,   62,
  280,  281,  282,   -1,   -1,  276,   -1,  278,   -1,  280,
  281,  282,  124,   37,   38,   -1,   -1,   -1,   42,   43,
   37,   45,   -1,   47,   -1,   42,   43,   -1,   45,   -1,
   47,   -1,   -1,   -1,   -1,   -1,   60,   61,   62,   -1,
  124,   -1,   -1,   60,   61,   62,   -1,   -1,  263,  264,
  265,  266,  267,  268,  263,  264,  265,  266,  267,  268,
  275,   -1,   -1,   -1,   -1,   -1,  275,   37,   38,   93,
   -1,   -1,   42,   43,   -1,   45,   -1,   47,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   59,
   60,   61,   62,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
  124,   -1,   37,   38,   -1,   -1,   -1,   42,   43,   -1,
   45,   -1,   47,   -1,   -1,   -1,   -1,   -1,   -1,  260,
  261,  262,  263,  264,   59,   60,   61,   62,   -1,   -1,
   -1,   -1,   37,   38,   -1,   -1,   -1,   42,   43,   -1,
   45,   -1,   47,   -1,   -1,   -1,   -1,   -1,  260,  261,
  262,  263,  264,   -1,  124,   60,   61,   62,   37,   38,
   -1,   -1,   -1,   42,   43,   -1,   45,   -1,   47,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  260,  261,  262,  263,
  264,   60,   61,   62,   -1,   -1,   -1,   -1,   -1,  124,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  261,  262,
  263,  264,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  124,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  260,  261,  262,  263,
  264,   -1,   59,  260,  261,  262,  263,  264,   65,   -1,
   -1,   -1,   69,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   81,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   91,   -1,   93,   -1,   95,   -1,
   -1,   98,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
  260,  261,  262,  263,  264,   -1,   -1,   -1,   -1,  116,
   -1,   -1,   -1,  120,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  141,  260,  261,  262,  263,  264,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   68,   -1,   70,   71,   72,   73,
   74,   75,   76,   -1,   -1,  260,  261,  262,  263,  264,
  177,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,  191,   -1,   -1,   -1,   -1,  196,
   -1,  260,  261,  262,  263,  264,  203,  204,  112,  113,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  122,  123,
  124,  125,  126,  127,  128,  129,  130,  131,  132,  133,
  134,  135,  136,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,  153,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
   -1,   -1,   -1,   -1,   -1,   -1,  180,   -1,  182,   -1,
   -1,   -1,   -1,   -1,  188,  189,
};
#define YYFINAL 1
#ifndef YYDEBUG
#define YYDEBUG 0
#endif
#define YYMAXTOKEN 323
#define YYUNDFTOKEN 348
#define YYTRANSLATE(a) ((a) > YYMAXTOKEN ? YYUNDFTOKEN : (a))
#if YYDEBUG
static const char *const yyname[] = {

"end-of-file",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
"'!'",0,"'#'",0,"'%'","'&'",0,"'('","')'","'*'","'+'","','","'-'",0,"'/'",0,0,0,
0,0,0,0,0,0,0,0,"';'","'<'","'='","'>'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,"'['",0,"']'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,"'{'","'|'","'}'","'~'",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"IF","ELSE","ASSIGN","DIF",
"GE","LE","INC","DEC","INT","STR","ID","NUM","VOID","INTEGER","STRING","NUMBER",
"FOR","PUBLIC","CONST","THEN","WHILE","DO","IN","STEP","UPTO","DOWNTO","BREAK",
"CONTINUE","FILES","NIL","DECLS","DECL","TYPE","IDp","VECT","INDIRECAO","SIM",
"MUL","DIV","RES","ADD","MIN","LESSER","GREATER","EQ","AND","OR","FUNC","FACT",
"INIT","PARAMS","PARAM","BODY","INSTRUCAO","INSTR","ARGS","ENDDECLS","ENDINIT",
"START","ALLOCATE","INSTRUCAOS","NULLARGS","NOSTEP","INFO","LOCALIZACAO",
"ERROR","VAR",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,"illegal-symbol",
};
static const char *const yyrule[] = {
"$accept : file",
"file : decls",
"decls : decls decl",
"decls :",
"decl : PUBLIC assign ';'",
"decl : PUBLIC init ';'",
"decl : assign ';'",
"decl : init ';'",
"decl : error ';'",
"decl : error '}'",
"assign : CONST tipo ID ASSIGN INT",
"assign : CONST tipo ID ASSIGN '-' INT",
"assign : CONST tipo ID ASSIGN CONST STR",
"assign : CONST tipo ID ASSIGN STR",
"assign : CONST tipo ID ASSIGN NUM",
"assign : CONST tipo ID ASSIGN '-' NUM",
"assign : CONST tipo ID ASSIGN ID",
"assign : CONST tipo ID",
"assign : tipo ID ASSIGN INT",
"assign : tipo ID ASSIGN '-' INT",
"assign : tipo ID ASSIGN CONST STR",
"assign : tipo ID ASSIGN STR",
"assign : tipo ID ASSIGN NUM",
"assign : tipo ID ASSIGN '-' NUM",
"assign : tipo ID ASSIGN ID",
"assign : tipo ID",
"$$1 :",
"init : tipo ID '(' parametro ')' '{' $$1 corpo '}'",
"init : tipo ID '(' parametro ')'",
"$$2 :",
"init : VOID ID '(' parametro ')' '{' $$2 corpo '}'",
"init : VOID ID '(' parametro ')'",
"$$3 :",
"init : tipo ID '(' ')' '{' $$3 corpo '}'",
"init : tipo ID '(' ')'",
"$$4 :",
"init : VOID ID '(' ')' '{' $$4 corpo '}'",
"init : VOID ID '(' ')'",
"parametro : parametro ',' tipo ID",
"parametro : tipo ID",
"corpo : param instrucaos",
"corpo : param",
"corpo : instrucaos",
"corpo :",
"param : param tipo ID ';'",
"param : tipo ID ';'",
"tipo : INTEGER",
"tipo : STRING",
"tipo : NUMBER",
"tipo : INTEGER '*'",
"tipo : STRING '*'",
"tipo : NUMBER '*'",
"lvalue : ID",
"lvalue : ID '[' expressao ']'",
"expressao : '(' expressao ')'",
"expressao : ID '(' arguments ')'",
"expressao : ID '(' ')'",
"expressao : '&' lvalue",
"expressao : '*' expressao",
"expressao : '!' expressao",
"expressao : '-' expressao",
"expressao : INC expressao",
"expressao : DEC expressao",
"expressao : expressao INC",
"expressao : expressao DEC",
"expressao : expressao '*' expressao",
"expressao : expressao '/' expressao",
"expressao : expressao '%' expressao",
"expressao : expressao '+' expressao",
"expressao : expressao '-' expressao",
"expressao : expressao '<' expressao",
"expressao : expressao '>' expressao",
"expressao : expressao GE expressao",
"expressao : expressao LE expressao",
"expressao : expressao '=' expressao",
"expressao : expressao DIF expressao",
"expressao : '~' expressao",
"expressao : expressao '&' expressao",
"expressao : expressao '|' expressao",
"expressao : lvalue ASSIGN expressao",
"expressao : values",
"values : INT",
"values : CONST STR",
"values : STR",
"values : NUM",
"values : lvalue",
"instrucaos : instrucaos instrucao",
"instrucaos : instrucao",
"instrucao : IF expressao addlvel THEN instrucao",
"instrucao : IF expressao addlvel THEN instrucao ELSE instrucao",
"instrucao : DO addlvel instrucao WHILE expressao ';'",
"instrucao : FOR lvalue IN expressao UPTO expressao step addlvel DO instrucao",
"instrucao : FOR lvalue IN expressao DOWNTO expressao step addlvel DO instrucao",
"instrucao : expressao ';'",
"instrucao : BREAK int ';'",
"instrucao : CONTINUE int ';'",
"instrucao : lvalue '#' expressao ';'",
"$$5 :",
"instrucao : '{' $$5 corpo '}'",
"instrucao : error ';'",
"instrucao : error '}'",
"addlvel :",
"int : INT",
"int :",
"step : STEP INT",
"step : STEP lvalue",
"step :",
"arguments : arguments ',' expressao",
"arguments : expressao",

};
#endif

int      yydebug;
int      yynerrs;

int      yyerrflag;
int      yychar;
YYSTYPE  yyval;
YYSTYPE  yylval;

/* define the initial stack-sizes */
#ifdef YYSTACKSIZE
#undef YYMAXDEPTH
#define YYMAXDEPTH  YYSTACKSIZE
#else
#ifdef YYMAXDEPTH
#define YYSTACKSIZE YYMAXDEPTH
#else
#define YYSTACKSIZE 10000
#define YYMAXDEPTH  10000
#endif
#endif

#define YYINITSTACKSIZE 200

typedef struct {
    unsigned stacksize;
    YYINT    *s_base;
    YYINT    *s_mark;
    YYINT    *s_last;
    YYSTYPE  *l_base;
    YYSTYPE  *l_mark;
} YYSTACKDATA;
/* variables for the parser stack */
static YYSTACKDATA yystack;
#line 237 "diy.y"

void printStruct(struct Args* asd){

	struct Args* aux = asd;

	while(aux != 0){
		printf("%d ", aux->type);
		aux = aux->next;
	}
	printf("\n");
}

struct Args* getParameters(Node* params){

	struct Args *aux = (struct Args*)malloc(sizeof(struct Args));

	if(params->attrib == TYPE){
		aux->type = LEFT_CHILD(params)->value.i;
		aux->name = RIGHT_CHILD(params)->value.s;
		aux->next = 0;
		return aux;
	}

	aux->next = getParameters(RIGHT_CHILD(params));
	
	struct Args* left = getParameters(LEFT_CHILD(params));
	
	aux->type = left->type;
	aux->name = left->name; 

	return aux; 
}


void existsID(Node* type, char* name){
	if(IDnew(type->value.i, name, 0) != 1){
		yyerror("Variable already exists");
	}
}

int checkAssign(Node* leftValue, Node* expr){

	if(checkConst(leftValue)){
		yyerror("Cannot assign to a constant left value");
		return leftValue->info;	
	}

	if(checkZero(expr)){
		return leftValue->info;
	}
	if((checkInt(leftValue)|| checkReal(leftValue)) && (checkInt(expr)|| checkReal(expr))){
		return leftValue->info;
	}

	if(checkString(leftValue) && (checkString(expr) || (checkInt(expr) && checkPointer(expr)))){
		return leftValue->info;
	}

	if( (checkInt(leftValue) && checkPointer(leftValue))  && (checkString(expr) || (checkInt(expr) && checkPointer(expr))) ){
		if(!checkRightConst(leftValue) && checkRightConst(expr)){
			IDreplace(leftValue->info, leftValue->value.s, 0);
		}
		return leftValue->info;
	}

	if( checkString(leftValue) && checkPointer(leftValue) && checkString(expr) && checkPointer(expr) ){
		if(!checkRightConst(leftValue) && checkRightConst(expr)){
			IDreplace(leftValue->info, leftValue->value.s, 0);
		}
		return leftValue->info;
	}

	if( checkReal(leftValue) && checkPointer(leftValue) && checkReal(expr) && checkPointer(expr)){
		if(!checkRightConst(leftValue) && checkRightConst(expr)){
			IDreplace(leftValue->info, leftValue->value.s, 0);
		}
		return leftValue->info;
	}

	yyerror("Assign types are not compatible");
	return leftValue->info;

}

void declareFunction(Node* typeFunc, char* name, Node* params){

	struct Args* arg = 0;

	if(params != 0){
		arg = getParameters(params);
	}

	if(IDnew(tFUNCT + typeFunc->value.i, name, (long)arg) == 1) {
		IDpush();
		IDnew(typeFunc->value.i, name, 0);
		
		if(params != 0){
			struct Args* aux = arg;

			while(aux->next != 0){
				IDnew(aux->type, aux->name, 0);
				aux = aux->next;
			}
			IDnew(aux->type, aux->name, 0);
		}
	}
	/*
	else{
		long * aux;
		int k = IDsearch(name, aux, 1, 0);
		printStruct((struct Args*)aux);
	}
	*/
}

int checkRightConst(Node* expr){
	if((expr->info / tCONSTR % 2) == 1){
		return 1;
	}
	return 0;
}
int checkLogics(Node* expr1, Node* expr2, char* errorMessage){
	if(checkInt(expr1) && checkInt(expr2) && !checkPointer(expr1) && !checkPointer(expr2)){
		return tINTEGER;
	}
	char error[50];
	sprintf(error, "Invalid type for %s", errorMessage);
	yyerror(error);
	return tINTEGER;
}

int checkAddress(int type){
	if((type / tPOINTER) % 2 == 0){
		return type + tPOINTER +tCONSTR;
	}

	yyerror("Invalid type for adressment");
	return type;
}

int checkMakePointer(Node* expr){
	if(checkPointer(expr) || checkString(expr)){
		int type = expr->info;
		if(checkConst(expr)){ type = type - tCONSTL;}
		if((expr->info / tCONSTR) % 2 == 1 && checkString(expr)) {return tINTEGER + tCONSTL;}  //if string and const direia ent passa a ser cont integer
		return (checkString(expr) ? tINTEGER : type - tPOINTER);
	}

	yyerror("Invalid type for pointer");
	return tINTEGER;
}

int checkIncrements(Node* expr, char* errorMessage){
	if(checkInt(expr) && !checkPointer(expr)){
		return tINTEGER;
	}
	char error[50];
	sprintf(error, "Invalid type for %s", errorMessage);
	yyerror(error);
	return tINTEGER;
}

int checkVector(int type){
	if((type / tPOINTER) % 2 == 0 && type % 4 != tSTRING){
		yyerror("Cannot index a non pointer type ");
		return type + tPOINTER;
	}
	int typeValue = type;
	if((type / tCONSTL) % 2 == 1){ typeValue = typeValue - tCONSTL;}
	if((type / tCONSTR) % 2 == 1 && type % 4 == 2) {return tINTEGER + tCONSTL;}
	return ((type % 4 == tSTRING && (type / tPOINTER) % 2 == 0) ? tINTEGER : typeValue - tPOINTER);
}

int checkSimetric(Node* expr, char* errorMessage){
	if(checkInt(expr) && !checkPointer(expr)){
		return tINTEGER;
	}

	if(checkReal(expr) && !checkPointer(expr)){
		return tNUMBER;
	}

	char error[50];
	sprintf(error, "Invalid type for %s", errorMessage);
	yyerror(error);
	
	return tNUMBER;

}
int checkFactorial(Node* expr, char* errorMessage){

	if(checkInt(expr) && !checkPointer(expr)){
		return tNUMBER;
	}

	char error[50];
	sprintf(error, "Invalid type for %s", errorMessage);
	yyerror(error);
	
	return tNUMBER;
}

int checkCalculus(Node* expr1, Node* expr2, char* errorMessage){

	if(checkInt(expr1) && checkInt(expr2)){
		return tINTEGER;
	}

	if((checkReal(expr1) || checkInt(expr1)) && (checkInt(expr2) || checkReal(expr2))){
		return tNUMBER;
	}

	char error[50];
	sprintf(error, "Invalid type for %s", errorMessage);
	yyerror(error);

	return tINTEGER;
}
int checkComparisons(Node* expr1, Node* expr2, char* errorMessage){

	if (checkInt(expr1) && checkInt(expr2) && !checkPointer(expr1) && !checkPointer(expr2)){
		return tINTEGER;	
	}
	//If they are of type int or number and are not pointer
	if(((checkInt(expr1)||checkReal(expr1)) && !checkPointer(expr1)) && ((checkInt(expr2)||checkReal(expr2)) && !checkPointer(expr2))){
		return tINTEGER;
	}

	//If they are both of type string and are not pointers
	if(checkString(expr1) && checkString(expr2) && !checkPointer(expr1) && !checkPointer(expr2)){
		return tINTEGER;
	}

	if(checkZero(expr1) || checkZero(expr2)){
		return tINTEGER;
	}

	char error[50];
	sprintf(error, "Invalid type for %s", errorMessage);
	yyerror(error);

	return tINTEGER;
}

int checkZero(Node* expr){
	if(expr->info / tZero == 1){
		return 1;
	}
	return 0;
}
int checkPointer(Node* expr){
	if((expr-> info / 16) % 2 == 1){
		return 1;
	}
	return 0;
}

int checkConst(Node* expr){
	if((expr->info / 8) % 2 == 1){
		return 1;
	}
	return 0;
}

int checkInt(Node* expr){
	if(expr->info % 4 == tINTEGER || checkZero(expr)){
		return 1;
	}
	return 0;
}

int checkReal(Node* expr){
	if(expr->info % 4 == tNUMBER || checkZero(expr)){
		return 1;
	}
	return 0;
}

int checkString(Node* expr){
	if(expr->info % 4 == tSTRING || checkZero(expr)){
		return 1;
	}
	return 0;
}

//Declaration checks
void checkIntDecl(Node* type, int value){
	if(!value || type->attrib == INTEGER){
		return;
	}
	yyerror("Invalid type for an integer");
}

void checkNumDecl(Node* type, int value){
	if(!value || type->attrib == NUMBER){
		return;
	}
	yyerror("Invalid type for an integer");
}

void checkStringDecl(Node *type){
	if(type->attrib == STRING || type->value.i == tINTEGER + tPOINTER){
		return;
	}
	yyerror("Invalid type for a string");
}

void checkID(Node *type, int idType){
	if(type->value.i == idType){
		return;
	}

	int id = idType % 4;

	if((type->attrib == INTEGER || type ->attrib == NUMBER) && (id == 1 || id == 3)){
		return;
	}

	if(type->value.i == tINTEGER + tPOINTER && id == 2){
		return;
	}

	yyerror("ID types do not match");
}

void checkDecl(Node* type, Node* init){
	//Checks arguments type and if its a declaration of a variable or a function
	(init->attrib == INIT ? yyerror("Function declarations cannot be constant") : 1);
	checkArgs(type, init);
}

void checkArgs(Node* type, Node* init){

	if(init->attrib != INIT && init->attrib != ENDINIT){
		if((type->attrib == INTEGER && init->info == tINTEGER) || (type->attrib == STRING && init->info == tSTRING) || (type->attrib == NUMBER && init->info == tNUMBER)){
			return;
		}
		yyerror("Types do no match");
	}
}


char **yynames =
#if YYDEBUG > 0
		 (char**)yyname;
#else
		 0;
#endif
#line 1121 "y.tab.c"

#if YYDEBUG
#include <stdio.h>		/* needed for printf */
#endif

#include <stdlib.h>	/* needed for malloc, etc */
#include <string.h>	/* needed for memset */

/* allocate initial stack or double stack size, up to YYMAXDEPTH */
static int yygrowstack(YYSTACKDATA *data)
{
    int i;
    unsigned newsize;
    YYINT *newss;
    YYSTYPE *newvs;

    if ((newsize = data->stacksize) == 0)
        newsize = YYINITSTACKSIZE;
    else if (newsize >= YYMAXDEPTH)
        return YYENOMEM;
    else if ((newsize *= 2) > YYMAXDEPTH)
        newsize = YYMAXDEPTH;

    i = (int) (data->s_mark - data->s_base);
    newss = (YYINT *)realloc(data->s_base, newsize * sizeof(*newss));
    if (newss == 0)
        return YYENOMEM;

    data->s_base = newss;
    data->s_mark = newss + i;

    newvs = (YYSTYPE *)realloc(data->l_base, newsize * sizeof(*newvs));
    if (newvs == 0)
        return YYENOMEM;

    data->l_base = newvs;
    data->l_mark = newvs + i;

    data->stacksize = newsize;
    data->s_last = data->s_base + newsize - 1;
    return 0;
}

#if YYPURE || defined(YY_NO_LEAKS)
static void yyfreestack(YYSTACKDATA *data)
{
    free(data->s_base);
    free(data->l_base);
    memset(data, 0, sizeof(*data));
}
#else
#define yyfreestack(data) /* nothing */
#endif

#define YYABORT  goto yyabort
#define YYREJECT goto yyabort
#define YYACCEPT goto yyaccept
#define YYERROR  goto yyerrlab

int
YYPARSE_DECL()
{
    int yym, yyn, yystate;
#if YYDEBUG
    const char *yys;

    if ((yys = getenv("YYDEBUG")) != 0)
    {
        yyn = *yys;
        if (yyn >= '0' && yyn <= '9')
            yydebug = yyn - '0';
    }
#endif

    yynerrs = 0;
    yyerrflag = 0;
    yychar = YYEMPTY;
    yystate = 0;

#if YYPURE
    memset(&yystack, 0, sizeof(yystack));
#endif

    if (yystack.s_base == NULL && yygrowstack(&yystack) == YYENOMEM) goto yyoverflow;
    yystack.s_mark = yystack.s_base;
    yystack.l_mark = yystack.l_base;
    yystate = 0;
    *yystack.s_mark = 0;

yyloop:
    if ((yyn = yydefred[yystate]) != 0) goto yyreduce;
    if (yychar < 0)
    {
        if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, reading %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
    }
    if ((yyn = yysindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: state %d, shifting to state %d\n",
                    YYPREFIX, yystate, yytable[yyn]);
#endif
        if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
        {
            goto yyoverflow;
        }
        yystate = yytable[yyn];
        *++yystack.s_mark = yytable[yyn];
        *++yystack.l_mark = yylval;
        yychar = YYEMPTY;
        if (yyerrflag > 0)  --yyerrflag;
        goto yyloop;
    }
    if ((yyn = yyrindex[yystate]) && (yyn += yychar) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yychar)
    {
        yyn = yytable[yyn];
        goto yyreduce;
    }
    if (yyerrflag) goto yyinrecovery;

    YYERROR_CALL("syntax error");

    goto yyerrlab;

yyerrlab:
    ++yynerrs;

yyinrecovery:
    if (yyerrflag < 3)
    {
        yyerrflag = 3;
        for (;;)
        {
            if ((yyn = yysindex[*yystack.s_mark]) && (yyn += YYERRCODE) >= 0 &&
                    yyn <= YYTABLESIZE && yycheck[yyn] == YYERRCODE)
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: state %d, error recovery shifting\
 to state %d\n", YYPREFIX, *yystack.s_mark, yytable[yyn]);
#endif
                if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
                {
                    goto yyoverflow;
                }
                yystate = yytable[yyn];
                *++yystack.s_mark = yytable[yyn];
                *++yystack.l_mark = yylval;
                goto yyloop;
            }
            else
            {
#if YYDEBUG
                if (yydebug)
                    printf("%sdebug: error recovery discarding state %d\n",
                            YYPREFIX, *yystack.s_mark);
#endif
                if (yystack.s_mark <= yystack.s_base) goto yyabort;
                --yystack.s_mark;
                --yystack.l_mark;
            }
        }
    }
    else
    {
        if (yychar == YYEOF) goto yyabort;
#if YYDEBUG
        if (yydebug)
        {
            yys = yyname[YYTRANSLATE(yychar)];
            printf("%sdebug: state %d, error recovery discards token %d (%s)\n",
                    YYPREFIX, yystate, yychar, yys);
        }
#endif
        yychar = YYEMPTY;
        goto yyloop;
    }

yyreduce:
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: state %d, reducing by rule %d (%s)\n",
                YYPREFIX, yystate, yyn, yyrule[yyn]);
#endif
    yym = yylen[yyn];
    if (yym)
        yyval = yystack.l_mark[1-yym];
    else
        memset(&yyval, 0, sizeof yyval);
    switch (yyn)
    {
case 1:
#line 103 "diy.y"
	{printNode(uniNode(FILES, yystack.l_mark[0].n),0,yynames);}
break;
case 2:
#line 105 "diy.y"
	{yyval.n = binNode(DECLS, yystack.l_mark[-1].n, yystack.l_mark[0].n);}
break;
case 3:
#line 106 "diy.y"
	{yyval.n = nilNode(ENDDECLS);}
break;
case 4:
#line 108 "diy.y"
	{yyval.n = binNode(DECL, nilNode(PUBLIC), yystack.l_mark[-1].n);}
break;
case 5:
#line 109 "diy.y"
	{yyval.n = binNode(DECL, nilNode(PUBLIC), yystack.l_mark[-1].n);}
break;
case 6:
#line 110 "diy.y"
	{yyval.n = uniNode(DECL, yystack.l_mark[-1].n);}
break;
case 7:
#line 111 "diy.y"
	{yyval.n = uniNode(DECL, yystack.l_mark[-1].n);}
break;
case 8:
#line 112 "diy.y"
	{yyval.n = strNode(ERROR, "error");}
break;
case 9:
#line 113 "diy.y"
	{yyval.n = strNode(ERROR, "error");}
break;
case 10:
#line 115 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), intNode(INT, yystack.l_mark[0].i)); IDnew((yystack.l_mark[0].i == 0 ? tZero : yystack.l_mark[-3].n->value.i + tCONSTL), yystack.l_mark[-2].s, 0); checkIntDecl(yystack.l_mark[-3].n, yystack.l_mark[0].i);}
break;
case 11:
#line 116 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-4].n, strNode(ID, yystack.l_mark[-3].s)), intNode(INT, -yystack.l_mark[0].i)); IDnew((yystack.l_mark[0].i == 0 ? tZero : yystack.l_mark[-4].n->value.i + tCONSTL), yystack.l_mark[-3].s, 0); checkIntDecl(yystack.l_mark[-4].n, yystack.l_mark[0].i);			}
break;
case 12:
#line 117 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-4].n, strNode(ID, yystack.l_mark[-3].s)), strNode(STR, yystack.l_mark[0].s)); IDnew(yystack.l_mark[-4].n->value.i + tCONSTL + tCONSTR, yystack.l_mark[-3].s, 0); checkStringDecl(yystack.l_mark[-4].n);}
break;
case 13:
#line 118 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), strNode(STR, yystack.l_mark[0].s)); IDnew(yystack.l_mark[-3].n->value.i + tCONSTL, yystack.l_mark[-2].s, 0); checkStringDecl(yystack.l_mark[-3].n);}
break;
case 14:
#line 119 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), realNode(NUM, yystack.l_mark[0].d)); IDnew(yystack.l_mark[-3].n->value.i + tCONSTL, yystack.l_mark[-2].s, 0); checkNumDecl(yystack.l_mark[-3].n, yystack.l_mark[0].d);}
break;
case 15:
#line 120 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-4].n, strNode(ID, yystack.l_mark[-3].s)), realNode(NUM, -yystack.l_mark[0].d)); IDnew(yystack.l_mark[-4].n->value.i + tCONSTL, yystack.l_mark[-3].s, 0); checkNumDecl(yystack.l_mark[-4].n, yystack.l_mark[0].d);}
break;
case 16:
#line 121 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), strNode(ID,yystack.l_mark[0].s)); 		IDnew(yystack.l_mark[-3].n->value.i + tCONSTL, yystack.l_mark[-2].s, 0); checkID(yystack.l_mark[-3].n, IDfind(yystack.l_mark[0].s,0));}
break;
case 17:
#line 122 "diy.y"
	{yyval.n = uniNode(VAR, binNode(TYPE, yystack.l_mark[-1].n, strNode(ID, yystack.l_mark[0].s))); IDnew(yystack.l_mark[-1].n->value.i + tCONSTL, yystack.l_mark[0].s, 0);}
break;
case 18:
#line 124 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), intNode(INT, yystack.l_mark[0].i));  IDnew((yystack.l_mark[0].i == 0 ? tZero : yystack.l_mark[-3].n->value.i), yystack.l_mark[-2].s, 0); checkIntDecl(yystack.l_mark[-3].n, yystack.l_mark[0].i);}
break;
case 19:
#line 125 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-4].n, strNode(ID, yystack.l_mark[-3].s)), intNode(INT, -yystack.l_mark[0].i)); IDnew((yystack.l_mark[0].i == 0 ? tZero : yystack.l_mark[-4].n->value.i), yystack.l_mark[-3].s, 0); checkIntDecl(yystack.l_mark[-4].n, yystack.l_mark[0].i);}
break;
case 20:
#line 126 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-4].n, strNode(ID, yystack.l_mark[-3].s)), strNode(STR, yystack.l_mark[0].s)); IDnew(yystack.l_mark[-4].n->value.i + tCONSTR, yystack.l_mark[-3].s, 0); checkStringDecl(yystack.l_mark[-4].n);}
break;
case 21:
#line 127 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), strNode(STR, yystack.l_mark[0].s)); IDnew(yystack.l_mark[-3].n->value.i, yystack.l_mark[-2].s, 0); checkStringDecl(yystack.l_mark[-3].n);}
break;
case 22:
#line 128 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), realNode(NUM, yystack.l_mark[0].d)); IDnew(yystack.l_mark[-3].n->value.i, yystack.l_mark[-2].s, 0); checkNumDecl(yystack.l_mark[-3].n, yystack.l_mark[0].d);}
break;
case 23:
#line 129 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-4].n, strNode(ID, yystack.l_mark[-3].s)), realNode(NUM, -yystack.l_mark[0].d)); IDnew(yystack.l_mark[-4].n->value.i, yystack.l_mark[-3].s, 0); checkNumDecl(yystack.l_mark[-4].n, yystack.l_mark[0].d);}
break;
case 24:
#line 130 "diy.y"
	{yyval.n = binNode(ASSIGN, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s)), strNode(ID,yystack.l_mark[0].s)); 		IDnew(yystack.l_mark[-3].n->value.i, yystack.l_mark[-2].s, 0); checkID(yystack.l_mark[-3].n, IDfind(yystack.l_mark[0].s,0));}
break;
case 25:
#line 131 "diy.y"
	{yyval.n = uniNode(VAR, binNode(TYPE, yystack.l_mark[-1].n, strNode(ID, yystack.l_mark[0].s))); IDnew(yystack.l_mark[-1].n->value.i, yystack.l_mark[0].s, 0);}
break;
case 26:
#line 133 "diy.y"
	{declareFunction(yystack.l_mark[-5].n, yystack.l_mark[-4].s, yystack.l_mark[-2].n);}
break;
case 27:
#line 133 "diy.y"
	{yyval.n = binNode(FUNC, binNode(TYPE, yystack.l_mark[-8].n, strNode(ID, yystack.l_mark[-7].s)), binNode(INIT, yystack.l_mark[-5].n, yystack.l_mark[-1].n)); IDpop();}
break;
case 28:
#line 134 "diy.y"
	{yyval.n = binNode(FUNC, binNode(TYPE, yystack.l_mark[-4].n, strNode(ID, yystack.l_mark[-3].s)), uniNode(INIT, yystack.l_mark[-1].n)); declareFunction(yystack.l_mark[-4].n, yystack.l_mark[-3].s, yystack.l_mark[-1].n); IDpop();}
break;
case 29:
#line 135 "diy.y"
	{declareFunction(intNode(VOID, tVOID), yystack.l_mark[-4].s, yystack.l_mark[-2].n);}
break;
case 30:
#line 135 "diy.y"
	{yyval.n = binNode(FUNC, binNode(TYPE, intNode(VOID, tVOID), strNode(ID, yystack.l_mark[-7].s)), binNode(INIT, yystack.l_mark[-5].n, yystack.l_mark[-1].n)); IDpop();}
break;
case 31:
#line 136 "diy.y"
	{yyval.n = binNode(FUNC, binNode(TYPE, intNode(VOID, tVOID), strNode(ID, yystack.l_mark[-3].s)), uniNode(INIT, yystack.l_mark[-1].n)); declareFunction(intNode(VOID, tVOID), yystack.l_mark[-3].s, yystack.l_mark[-1].n); IDpop();}
break;
case 32:
#line 138 "diy.y"
	{declareFunction(yystack.l_mark[-4].n, yystack.l_mark[-3].s, 0);}
break;
case 33:
#line 138 "diy.y"
	{yyval.n = uniNode(FUNC, binNode(TYPE, yystack.l_mark[-7].n, strNode(ID, yystack.l_mark[-6].s))); IDpop();}
break;
case 34:
#line 139 "diy.y"
	{yyval.n = uniNode(FUNC, binNode(TYPE, yystack.l_mark[-3].n, strNode(ID, yystack.l_mark[-2].s))); declareFunction(yystack.l_mark[-3].n, yystack.l_mark[-2].s, 0); IDpop();}
break;
case 35:
#line 140 "diy.y"
	{declareFunction(intNode(VOID, tVOID), yystack.l_mark[-3].s, 0);}
break;
case 36:
#line 140 "diy.y"
	{yyval.n = uniNode(FUNC, binNode(TYPE, intNode(VOID, tVOID), strNode(ID, yystack.l_mark[-6].s))); IDpop();}
break;
case 37:
#line 141 "diy.y"
	{yyval.n = uniNode(FUNC, binNode(TYPE, intNode(VOID, tVOID), strNode(ID, yystack.l_mark[-2].s))); declareFunction(intNode(VOID, tVOID), yystack.l_mark[-2].s, 0); IDpop();}
break;
case 38:
#line 143 "diy.y"
	{yyval.n = binNode(PARAM, binNode(TYPE, yystack.l_mark[-1].n, strNode(ID, yystack.l_mark[0].s)), yystack.l_mark[-3].n);}
break;
case 39:
#line 144 "diy.y"
	{yyval.n = binNode(TYPE, yystack.l_mark[-1].n, strNode(ID, yystack.l_mark[0].s));}
break;
case 40:
#line 146 "diy.y"
	{yyval.n = binNode(BODY, yystack.l_mark[-1].n, yystack.l_mark[0].n);}
break;
case 41:
#line 147 "diy.y"
	{yyval.n = uniNode(BODY, yystack.l_mark[0].n);}
break;
case 42:
#line 148 "diy.y"
	{yyval.n = uniNode(BODY, yystack.l_mark[0].n);}
break;
case 43:
#line 149 "diy.y"
	{yyval.n = nilNode(NIL);}
break;
case 44:
#line 151 "diy.y"
	{yyval.n = binNode(PARAM, binNode(TYPE, yystack.l_mark[-2].n, strNode(ID, yystack.l_mark[-1].s)), yystack.l_mark[-3].n); existsID(yystack.l_mark[-2].n, yystack.l_mark[-1].s);}
break;
case 45:
#line 152 "diy.y"
	{yyval.n = binNode(TYPE, yystack.l_mark[-2].n, strNode(ID, yystack.l_mark[-1].s)); existsID(yystack.l_mark[-2].n, yystack.l_mark[-1].s);}
break;
case 46:
#line 154 "diy.y"
	{yyval.n = intNode(INTEGER, tINTEGER);}
break;
case 47:
#line 155 "diy.y"
	{yyval.n = intNode(STRING, tSTRING);}
break;
case 48:
#line 156 "diy.y"
	{yyval.n = intNode(NUMBER, tNUMBER);}
break;
case 49:
#line 157 "diy.y"
	{yyval.n = intNode(INTEGER, tINTEGER + tPOINTER);}
break;
case 50:
#line 158 "diy.y"
	{yyval.n = intNode(STRING, tSTRING + tPOINTER);}
break;
case 51:
#line 159 "diy.y"
	{yyval.n = intNode(NUMBER, tNUMBER + tPOINTER);}
break;
case 52:
#line 161 "diy.y"
	{yyval.n = strNode(ID,yystack.l_mark[0].s); yyval.n->info = IDfind(yystack.l_mark[0].s, 0);}
break;
case 53:
#line 162 "diy.y"
	{yyval.n = binNode(VECT, strNode(ID, yystack.l_mark[-3].s), yystack.l_mark[-1].n); yyval.n->info = checkVector(IDfind(yystack.l_mark[-3].s, 0));}
break;
case 54:
#line 164 "diy.y"
	{yyval.n = yystack.l_mark[-1].n;}
break;
case 55:
#line 165 "diy.y"
	{yyval.n = binNode(FUNC, strNode(ID, yystack.l_mark[-3].s), yystack.l_mark[-1].n); yyval.n->info = IDfind(yystack.l_mark[-3].s,0)%tFUNCT;}
break;
case 56:
#line 166 "diy.y"
	{yyval.n = uniNode(FUNC, strNode(ID, yystack.l_mark[-2].s)); yyval.n->info = IDfind(yystack.l_mark[-2].s,0)%tFUNCT;}
break;
case 57:
#line 168 "diy.y"
	{yyval.n = uniNode(LOCALIZACAO, yystack.l_mark[0].n); yyval.n->info = checkAddress(yystack.l_mark[0].n->info);}
break;
case 58:
#line 169 "diy.y"
	{yyval.n = uniNode(INDIRECAO, yystack.l_mark[0].n); yyval.n->info = checkMakePointer(yystack.l_mark[0].n);}
break;
case 59:
#line 171 "diy.y"
	{yyval.n = uniNode(FACT, yystack.l_mark[0].n); 		yyval.n->info = checkFactorial(yystack.l_mark[0].n, "factorial");}
break;
case 60:
#line 172 "diy.y"
	{yyval.n = uniNode(SIM, yystack.l_mark[0].n); 		yyval.n->info = checkSimetric(yystack.l_mark[0].n, "simetric");}
break;
case 61:
#line 174 "diy.y"
	{yyval.n = uniNode(INC, yystack.l_mark[0].n); 		yyval.n->info = checkIncrements(yystack.l_mark[0].n, "increment");}
break;
case 62:
#line 175 "diy.y"
	{yyval.n = uniNode(DEC, yystack.l_mark[0].n); 		yyval.n->info = checkIncrements(yystack.l_mark[0].n, "decrement");}
break;
case 63:
#line 176 "diy.y"
	{yyval.n = uniNode(INC, yystack.l_mark[-1].n);		 	yyval.n->info = checkIncrements(yystack.l_mark[-1].n, "increment");}
break;
case 64:
#line 177 "diy.y"
	{yyval.n = uniNode(DEC, yystack.l_mark[-1].n); 		yyval.n->info = checkIncrements(yystack.l_mark[-1].n, "decrement");}
break;
case 65:
#line 179 "diy.y"
	{yyval.n = binNode(MUL, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkCalculus(yystack.l_mark[-2].n, yystack.l_mark[0].n, "multiplication");}
break;
case 66:
#line 180 "diy.y"
	{yyval.n = binNode(DIV, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkCalculus(yystack.l_mark[-2].n, yystack.l_mark[0].n, "division");}
break;
case 67:
#line 181 "diy.y"
	{yyval.n = binNode(RES, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkCalculus(yystack.l_mark[-2].n, yystack.l_mark[0].n, "rest");}
break;
case 68:
#line 182 "diy.y"
	{yyval.n = binNode(ADD, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkCalculus(yystack.l_mark[-2].n, yystack.l_mark[0].n, "addition");}
break;
case 69:
#line 183 "diy.y"
	{yyval.n = binNode(MIN, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkCalculus(yystack.l_mark[-2].n, yystack.l_mark[0].n, "subtraction");}
break;
case 70:
#line 185 "diy.y"
	{yyval.n = binNode(LESSER, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkComparisons(yystack.l_mark[-2].n, yystack.l_mark[0].n, "lesser");}
break;
case 71:
#line 186 "diy.y"
	{yyval.n = binNode(GREATER, yystack.l_mark[-2].n, yystack.l_mark[0].n); yyval.n->info = checkComparisons(yystack.l_mark[-2].n, yystack.l_mark[0].n, "greater");}
break;
case 72:
#line 187 "diy.y"
	{yyval.n = binNode(GE, yystack.l_mark[-2].n, yystack.l_mark[0].n); 		yyval.n->info = checkComparisons(yystack.l_mark[-2].n, yystack.l_mark[0].n, "greater or equal");}
break;
case 73:
#line 188 "diy.y"
	{yyval.n = binNode(LE, yystack.l_mark[-2].n, yystack.l_mark[0].n); 		yyval.n->info = checkComparisons(yystack.l_mark[-2].n, yystack.l_mark[0].n, "lesser or equal");}
break;
case 74:
#line 189 "diy.y"
	{yyval.n = binNode(EQ, yystack.l_mark[-2].n, yystack.l_mark[0].n); 		yyval.n->info = checkComparisons(yystack.l_mark[-2].n, yystack.l_mark[0].n, "equality");}
break;
case 75:
#line 190 "diy.y"
	{yyval.n = binNode(DIF, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkComparisons(yystack.l_mark[-2].n, yystack.l_mark[0].n, "different");}
break;
case 76:
#line 192 "diy.y"
	{yyval.n = uniNode(RES, yystack.l_mark[0].n); 		yyval.n->info = checkIncrements(yystack.l_mark[0].n, "negation");}
break;
case 77:
#line 194 "diy.y"
	{yyval.n = binNode(AND, yystack.l_mark[-2].n, yystack.l_mark[0].n);		yyval.n->info = checkLogics(yystack.l_mark[-2].n, yystack.l_mark[0].n, "AND");}
break;
case 78:
#line 195 "diy.y"
	{yyval.n = binNode(OR, yystack.l_mark[-2].n, yystack.l_mark[0].n); 		yyval.n->info = checkLogics(yystack.l_mark[-2].n, yystack.l_mark[0].n, "OR");}
break;
case 79:
#line 197 "diy.y"
	{yyval.n = binNode(ASSIGN, yystack.l_mark[-2].n, yystack.l_mark[0].n); 	yyval.n->info = checkAssign(yystack.l_mark[-2].n, yystack.l_mark[0].n);}
break;
case 80:
#line 199 "diy.y"
	{yyval.n = yystack.l_mark[0].n;}
break;
case 81:
#line 201 "diy.y"
	{yyval.n = intNode(INT, yystack.l_mark[0].i); if(yystack.l_mark[0].i == 0){yyval.n->info = tZero;} else{yyval.n->info = tINTEGER;};}
break;
case 82:
#line 202 "diy.y"
	{yyval.n = strNode(STR, yystack.l_mark[0].s); yyval.n->info = tSTRING + tCONSTR;}
break;
case 83:
#line 203 "diy.y"
	{yyval.n = strNode(STR, yystack.l_mark[0].s); yyval.n->info = tSTRING;}
break;
case 84:
#line 204 "diy.y"
	{yyval.n = realNode(NUM, yystack.l_mark[0].d); yyval.n->info = tNUMBER;}
break;
case 85:
#line 205 "diy.y"
	{yyval.n = yystack.l_mark[0].n;}
break;
case 86:
#line 207 "diy.y"
	{yyval.n = binNode(INSTRUCAOS, yystack.l_mark[-1].n, yystack.l_mark[0].n);}
break;
case 87:
#line 208 "diy.y"
	{yyval.n = uniNode(INSTRUCAO, yystack.l_mark[0].n);}
break;
case 88:
#line 210 "diy.y"
	{yyval.n = binNode(IF, yystack.l_mark[-3].n, yystack.l_mark[0].n); if(yystack.l_mark[-3].n->info != tINTEGER){yyerror("Invalid type for IF expression");}; level--;}
break;
case 89:
#line 211 "diy.y"
	{yyval.n = binNode(ELSE, binNode(IF, yystack.l_mark[-5].n, yystack.l_mark[-2].n), yystack.l_mark[0].n); if(yystack.l_mark[-5].n->info != tINTEGER){yyerror("Invalid type for IF expression");}; level--;}
break;
case 90:
#line 212 "diy.y"
	{yyval.n = binNode(WHILE, binNode(DO, nilNode(START), yystack.l_mark[-3].n), yystack.l_mark[-1].n); if(yystack.l_mark[-1].n->info != tINTEGER){yyerror("Invalid type for DO WHILE expression");}; level--;}
break;
case 91:
#line 213 "diy.y"
	{yyval.n = binNode(FOR, binNode(IN, yystack.l_mark[-8].n,binNode(UPTO,binNode(STEP,yystack.l_mark[-6].n,yystack.l_mark[-3].n),yystack.l_mark[-4].n)), uniNode(DO, yystack.l_mark[0].n)); level--;}
break;
case 92:
#line 214 "diy.y"
	{yyval.n = binNode(FOR, binNode(IN, yystack.l_mark[-8].n,binNode(DOWNTO,binNode(STEP,yystack.l_mark[-6].n,yystack.l_mark[-3].n),yystack.l_mark[-4].n)), uniNode(DO, yystack.l_mark[0].n)); level--;}
break;
case 93:
#line 215 "diy.y"
	{yyval.n = yystack.l_mark[-1].n;}
break;
case 94:
#line 216 "diy.y"
	{yyval.n = uniNode(BREAK, yystack.l_mark[-1].n); if(level<yystack.l_mark[-1].n->value.i){yyerror("Integer of break too big for number of cycles");}}
break;
case 95:
#line 217 "diy.y"
	{yyval.n = uniNode(CONTINUE, yystack.l_mark[-1].n); if(level<yystack.l_mark[-1].n->value.i){yyerror("Integer of continue too big for number of cycles");}}
break;
case 96:
#line 218 "diy.y"
	{yyval.n = binNode(ALLOCATE, yystack.l_mark[-3].n, yystack.l_mark[-1].n);}
break;
case 97:
#line 219 "diy.y"
	{IDpush();}
break;
case 98:
#line 219 "diy.y"
	{yyval.n = yystack.l_mark[-1].n; IDpop();}
break;
case 99:
#line 220 "diy.y"
	{yyval.n = strNode(ERROR, "error");}
break;
case 100:
#line 221 "diy.y"
	{yyval.n = strNode(ERROR, "error");}
break;
case 101:
#line 223 "diy.y"
	{level++;}
break;
case 102:
#line 225 "diy.y"
	{yyval.n = intNode(INT, yystack.l_mark[0].i);}
break;
case 103:
#line 226 "diy.y"
	{yyval.n = intNode(INT, 1);}
break;
case 104:
#line 228 "diy.y"
	{yyval.n = intNode(INT, yystack.l_mark[0].i);}
break;
case 105:
#line 229 "diy.y"
	{yyval.n = yystack.l_mark[0].n;}
break;
case 106:
#line 230 "diy.y"
	{yyval.n = nilNode(NOSTEP);}
break;
case 107:
#line 232 "diy.y"
	{yyval.n = binNode(ARGS, yystack.l_mark[-2].n, yystack.l_mark[0].n);}
break;
case 108:
#line 233 "diy.y"
	{yyval.n = yystack.l_mark[0].n;}
break;
#line 1755 "y.tab.c"
    }
    yystack.s_mark -= yym;
    yystate = *yystack.s_mark;
    yystack.l_mark -= yym;
    yym = yylhs[yyn];
    if (yystate == 0 && yym == 0)
    {
#if YYDEBUG
        if (yydebug)
            printf("%sdebug: after reduction, shifting from state 0 to\
 state %d\n", YYPREFIX, YYFINAL);
#endif
        yystate = YYFINAL;
        *++yystack.s_mark = YYFINAL;
        *++yystack.l_mark = yyval;
        if (yychar < 0)
        {
            if ((yychar = YYLEX) < 0) yychar = YYEOF;
#if YYDEBUG
            if (yydebug)
            {
                yys = yyname[YYTRANSLATE(yychar)];
                printf("%sdebug: state %d, reading %d (%s)\n",
                        YYPREFIX, YYFINAL, yychar, yys);
            }
#endif
        }
        if (yychar == YYEOF) goto yyaccept;
        goto yyloop;
    }
    if ((yyn = yygindex[yym]) && (yyn += yystate) >= 0 &&
            yyn <= YYTABLESIZE && yycheck[yyn] == yystate)
        yystate = yytable[yyn];
    else
        yystate = yydgoto[yym];
#if YYDEBUG
    if (yydebug)
        printf("%sdebug: after reduction, shifting from state %d \
to state %d\n", YYPREFIX, *yystack.s_mark, yystate);
#endif
    if (yystack.s_mark >= yystack.s_last && yygrowstack(&yystack) == YYENOMEM)
    {
        goto yyoverflow;
    }
    *++yystack.s_mark = (YYINT) yystate;
    *++yystack.l_mark = yyval;
    goto yyloop;

yyoverflow:
    YYERROR_CALL("yacc stack overflow");

yyabort:
    yyfreestack(&yystack);
    return (1);

yyaccept:
    yyfreestack(&yystack);
    return (0);
}
